#include <WiFi.h>
#include <HTTPClient.h>
#include <UrlEncode.h>

const char* ssid = "Redmi Note 7";
const char* password = "jtct7903";

const int sensorPin = 21; // Pino do sensor de presença
const int ledVermelho = 19; // Pino do LED vermelho
const int ledAmarelo = 18; // Pino do LED amarelo
const int ledVerde = 5; // Pino do LED verde

String phoneNumber = "+554192270628";
String apiKey = "4467246";

bool flag = 1;  // Added missing flag variable declaration

void sendMessage(String message) {
  String url = "https://api.callmebot.com/whatsapp.php?phone=" + phoneNumber + "&apikey=" + apiKey + "&text=" + urlEncode(message);
  
  HTTPClient http;
  http.begin(url);
  
  http.addHeader("Content-Type", "application/x-www-form-urlencoded");
  
  int httpResponseCode = http.POST(url);
  if (httpResponseCode == 200) {
    Serial.println("Mensagem enviada com sucesso");
  } else {
    Serial.println("Erro no envio da mensagem");
    Serial.print("HTTP response code: ");
    Serial.println(httpResponseCode);
  }
  
  // Free resources
  http.end();
}


void setup() {
  Serial.begin(115200);
  
  pinMode(sensorPin, INPUT);  // Fixed capitalization
  pinMode(ledVermelho, OUTPUT);   // Added missing pinMode for ledVermelho
  pinMode(ledAmarelo, OUTPUT);   // Added missing pinMode for ledAmarelo
  pinMode(ledVerde, OUTPUT);   // Added missing pinMode for ledVerde
  
  WiFi.begin(ssid, password);
  Serial.println("Conectando");
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("");
  Serial.print("Conectado ao WiFi neste IP ");
  Serial.println(WiFi.localIP());
  pinMode(sensorPin, INPUT); // Configura o pino do sensor de presença como entrada
  pinMode(ledVermelho, OUTPUT); // Configura o pino do LED vermelho como saída
  pinMode(ledAmarelo, OUTPUT); // Configura o pino do LED amarelo como saída
  pinMode(ledVerde, OUTPUT); // Configura o pino do LED verde como saída
}

void loop() {
  int sensorValue = digitalRead(sensorPin); // Lê o valor do sensor de presença

  if (sensorValue == HIGH) { // Se o sensor detectar presença
    
    //sendMessage("Invadiu!");
      
    digitalWrite(ledVermelho, HIGH); // Liga o LED vermelho
    delay(2000); // Espera 2 segundos
    digitalWrite(ledVermelho, LOW); // Desliga o LED vermelho
    digitalWrite(ledAmarelo, HIGH); // Liga o LED amarelo
    delay(1000); // Espera 1 segundo
    digitalWrite(ledAmarelo, LOW); // Desliga o LED amarelo
    digitalWrite(ledVerde, HIGH); // Liga o LED verde
    delay(2000); // Espera 2 segundos
    digitalWrite(ledVerde, LOW); // Desliga o LED verde

    sendMessage("Detecção de movimento suspeito na área");

  } else { // Se o sensor não detectar presença
    digitalWrite(ledVermelho, LOW); // Desliga o LED vermelho
    digitalWrite(ledAmarelo, LOW); // Desliga o LED amarelo
    digitalWrite(ledVerde, LOW); // Desliga o LED verde
  }
}